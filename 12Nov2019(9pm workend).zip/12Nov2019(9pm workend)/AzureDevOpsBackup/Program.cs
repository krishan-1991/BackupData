﻿using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Extensions;
using System.Reflection;
using System.Text;
using System.Configuration;

namespace AzureDevOpsBackup
{
    struct Project
    {
        public string name;
    }
    struct Projects
    {
        public List<Project> value;
    }
    struct Repo
    {
        public string id;
        public string name;
    }
    struct Repos
    {
        public List<Repo> value;
    }
    struct Item
    {
        public string objectId;
        public string gitObjectType;
        public string commitId;
        public string path;
        public bool isFolder;
        public string url;
    }
    struct Items
    {
        public int count;
        public List<Item> value;
    }

    //new 

    struct Object
    {
        public string sha;
        public string type;
        public string url;
    }
    struct MastrbrnchDetails
    {
        public string Ref;
        public Object objecT;

    }

    struct GitRepos
    {
        public int id;
        public string name;
    }

    struct GitReposList
    {
        public List<GitRepos> value;
    }

    struct Gitbranch
    {
        public string name;    
        public GitCommit commit;
    }
    struct GitbrancList
    {
        public List<Gitbranch> value;
    }

    struct GitCommit
    {
        public string sha;
        public string url;
    }

    struct brancH
    {
        public string name;
        public string objectId;
        public string url;
    }
    struct brancheS
    {
        public List<brancH> value;
    }
    struct author
    {
        public string name;
        public string email;
    }

    struct Latestcommit
    {
        public string treeId;
        public string commitId;
        public author author;
        public author committer;
        public string comment;
    }
    struct tsts
    {
        public tests item;
        public string changeType;
    }
    struct tests
    {
        public string objectId;
        public string gitObjectType;
        public string commitId;
        public string path;
        public bool isFolder;
        public string comment;
        public string url;
    }
    struct changcount
    {
        public int Add;
    }
    struct CommitedFiles
    {
        public changcount changeCounts;
        public List<tsts> changes;
    }

    struct FileDetails
    {
        public string name;
        public string path;
        public string sha;
        public int size;
        public string type;
        public string encoding;
    }

    class Getfiles
    {
        public List<string> GetAllFiles(string sDirt)
        {
            List<string> files = new List<string>();

            try
            {
                foreach (string file in Directory.GetFiles(sDirt))
                {
                    files.Add(file);
                }
                foreach (string fl in Directory.GetDirectories(sDirt))
                {
                    files.AddRange(GetAllFiles(fl));
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }

            return files;
        }
    }



    class Program  
    {
           
        public void Updatefile(string comment, author objauthor,string filepath)
       {
            string giturl = ConfigurationManager.AppSettings["gitUrl"];
            string gitbaseURL = giturl;

            // var fullFileName = "test2.txt";
            //var filepath = @"D:\research\AzureBackupToLocalRepo\AspCoreApp\Azurebackup\AspCoreApp_AspCoreApp";

            //var filepath = @"D:\AzurebackupCommit\AspCoreApp_AspCoreApp\AspCoreApp";
            //  var filepath = @"D:\research\AzureCloneToLocalRepo\AspCoreAppp\Azurebackup\AspCoreApp_AspCoreApp\AspCoreApp";


            ////refs/heads/test2
            // string path = branchname+"/";
            //  string latestbranchname = Path.GetFileName(Path.GetDirectoryName(path));

             Getfiles objGetfiles = new Getfiles();
             List<string> lstfiles = objGetfiles.GetAllFiles(filepath);

 //// ******************  New Code For Get Master branch Sha_id from github 

 //           string bseUrl = "https://api.github.com/repos/krishan-1991/demo/git/refs/heads/master";
 //           var clenT = new RestClient(bseUrl);
 //           var rqusT = new RestRequest(Method.GET);
 //           IRestResponse respnsE = clenT.Execute(rqusT);
 //           var mastrbrnchdetals = JsonConvert.DeserializeObject<MastrbrnchDetails>(respnsE.Content);

 ////// Code for Create a branch inside Github.  

 //           // var clients = new RestClient("https://api.github.com/repos/krishan-1991/demo/git/refs");
 //           var clients = new RestClient(gitbaseURL + "demo/git/refs");
 //           var requests = new RestRequest(Method.POST);
 //           requests.AddHeader("user-agent", "request");
 //           requests.AddHeader("content-type", "application/json");
 //           requests.AddHeader("authorization", "token 09939e9fb363e68a048bbabd9c6e23e13a01ca48");

 //          // requests.AddParameter("application/json", "{\n  \"ref\": \"refs/heads/krishantTestBranch\",\n  \"sha\": \"d80cc875918dfa93d31e8c0caee81abaecf4bf79\"\n}\n\t\n\t\n", ParameterType.RequestBody);

 //           requests.AddParameter("application/json", "{\n  \"ref\": \""+branchname +"\",\n  \"sha\": \"" + mastrbrnchdetals.objecT.sha + "\"\n}\n\t\n\t\n", ParameterType.RequestBody);
 //           IRestResponse objresponse = clients.Execute(requests);

 //    ////End Code.   

            foreach (var dir in lstfiles)  
                {
             
                FileInfo objFileInfo  = new FileInfo(dir); 
                string[] strfilelist = File.ReadAllLines(dir);

  //// New Code For Get Sha_Id to Update File on Github.

                // string baseUrl = "https://api.github.com/repos/krishan-1991/demo/contents/" + objFileInfo.Name;
                string baseUrl = gitbaseURL+ "AzureBackup/contents/+" + objFileInfo.Name;
                var clienT = new RestClient(baseUrl);
                var requesT = new RestRequest(Method.GET);
                IRestResponse responsE = clienT.Execute(requesT);
                var filedetails = JsonConvert.DeserializeObject<FileDetails>(responsE.Content);
                var shaid = filedetails.sha;
                Console.Write("\n\t File's Sha_Id To Update File : " + shaid);

  //// ********* End New Code ********

                string baseURL = gitbaseURL + "AzureBackup/contents/+" + objFileInfo;
                //  string baseURL = "https://api.github.com/repos/krishan-1991/AzureBackup/contents/" + objFileInfo;
                // string baseURL = "https://api.github.com/repos/krishan-1991/AzureBackup/contents/" + objFileInfo.Name;
                // string baseURL = "https://api.github.com/repos/krishan-1991/AzureBackup/contents/" + fullFileName;

                var client = new RestClient(baseURL);                          
                var request = new RestRequest(Method.PUT);
                request.AddHeader("User-Agent", "request");
                //request.AddHeader("Content-Type", "application/json,application/json");
                request.AddHeader("Content-Type", "application/json;charset=utf-8");
                request.AddHeader("Authorization", "token 09939e9fb363e68a048bbabd9c6e23e13a01ca48");

                string test = string.Join("\n", strfilelist);
                byte[] bytes = Encoding.ASCII.GetBytes(test); 

                      request.AddParameter("undefined",
             "\n{\"message\":\"" + comment + "\",\n\"committer\":{\n\t\"name\":\"" + objauthor.name + "\",\n\t\"email\":\"" + objauthor.email + "\"\n},\n\"content\":\"" + Convert.ToBase64String(bytes) + "\",\n\"sha\":\"" + filedetails.sha +"\"\n\t\n}", ParameterType.RequestBody);

                //   request.AddParameter("undefined",
                //"\n{\"message\":\""+ comment + "\",\n\"committer\":{\n\t\"name\":\"" + objauthor.name + "\",\n\t\"email\":\"" + objauthor.email + "\"\n},\n\"content\":\"" + Convert.ToBase64String(bytes) + "\",\n\"sha\":\"e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\"\n\t\n}", ParameterType.RequestBody);

                //  request.AddParameter("undefined",  
                //"\n{\"message\":\"kris Commited Content\",\n\"committer\":{\n\t\"name\":\"krishan-1991\",\n\t\"email\":\"skrishan899@gmail.com\"\n},\n\"content\":\"" + Convert.ToBase64String(bytes) + "\",\n\"sha\":\"e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\"\n\t\n}", ParameterType.RequestBody);

                //request.AddParameter("undefined",
                //    "\n{\"message\":\"Mukesh Commited file\",\n\"committer\":{\n\t\"name\":\"krishan-1991\",\n\t\"email\":\"skrishan899@gmail.com\"\n},\n\"content\":\"bXkgbmV3IGZpbGUgY29udGVudHM=\",\n\"sha\":\"0d5a690c8fad5e605a6e8766295d9d459d65de42\"\n\t\n}", ParameterType.RequestBody);

                IRestResponse response = client.Execute(request);

           }

        }

       

        static void Main(string[] args)
        {
            //@"D:\AzurebackupCommit\"
            string spath=""; string fpath=""; string pathh="";
            string sFILE_PATH = ConfigurationManager.AppSettings["outdirs"]; 
            string FILE_PATH = ConfigurationManager.AppSettings["dir"];
            string giturl = ConfigurationManager.AppSettings["gitUrl"];
            string gitUrlrepo = ConfigurationManager.AppSettings["gitUrlrepo"];

            Program objprogram = new Program();
          //  objprogram.test();

            string[] requiredArgs = { "--token", "--organization", "--outdir" };

            if (args.Intersect(requiredArgs).Count() == 3)
            {
                const string version = "api-version=5.1-preview.1";
                string auth = "Basic " + Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "", args[Array.IndexOf(args, "--token") + 1])));
                string baseURL = "https://dev.azure.com/" + args[Array.IndexOf(args, "--organization") + 1] + "/";
                string gitbaseURL =  giturl;
                string outDir = args[Array.IndexOf(args, "--outdir") + 1] + "\\";
                var clientProjects = new RestClient(baseURL + "_apis/projects?" + version);
                var requestProjects = new RestRequest(Method.GET);
                requestProjects.AddHeader("Authorization", auth);
                IRestResponse responseProjects = clientProjects.Execute(requestProjects);
                Projects projects = JsonConvert.DeserializeObject<Projects>(responseProjects.Content);
                foreach (Project project in projects.value)
                {
                    Console.WriteLine(project.name);
                    var clientRepos = new RestClient(baseURL + project.name + "/_apis/git/repositories?" + version);
                    var requestRepos = new RestRequest(Method.GET);
                    requestRepos.AddHeader("Authorization", auth);
                    IRestResponse responseRepos = clientRepos.Execute(requestRepos);
                    Repos repos = JsonConvert.DeserializeObject<Repos>(responseRepos.Content);
                    foreach (Repo repo in repos.value)
                    {

                        //old code 

                        Console.Write("\n\t" + repo.name);
                        var clientItems = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/items?recursionlevel=full&" + version);
                        var requestItems = new RestRequest(Method.GET);
                        requestItems.AddHeader("Authorization", auth);
                        IRestResponse responseItems = clientItems.Execute(requestItems);
                        Items items = JsonConvert.DeserializeObject<Items>(responseItems.Content);
                        Console.Write(" - " + items.count + "\n");

  //// New Code for get all branches from Repository (Azure).

                        var clientIt = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/refs?" + version);  // test for get all branches
                        var requestIte = new RestRequest(Method.GET);
                        requestIte.AddHeader("Authorization", auth);
                        IRestResponse responseIt = clientIt.Execute(requestIte);
                        var branChes = JsonConvert.DeserializeObject<brancheS>(responseIt.Content);
                        Console.WriteLine("Number of Branches in " + repo.name + " Repository :" + branChes.value.Count);
                        var branchid="";
                        List<Gitbranch> Gitbranches = new List<Gitbranch>();

                        //foreach (brancH branc in branChes.value)
                        //{
                        //    Console.WriteLine("Branch_Name : " + branc.name + " & Branch_Id  :  " + branc.objectId);
                        //    branchid = branc.objectId;
                        //    // Azurebranchname = branc.name;

                        //    // string path = branchname+"/";
                        //    //  string latestbranchname = Path.GetFileName(Path.GetDirectoryName(path));

                        //    string path = branc.name + "/";
                        //    Azurebranchname = Path.GetFileName(Path.GetDirectoryName(path));


  //// Get all branch from Github Repository.

                            var clntIt = new RestClient(gitbaseURL + "AzureBackup/branches");
                            var reqst = new RestRequest(Method.GET);
                            reqst.AddHeader("Content-Type", "text/plain");
                            reqst.AddHeader("Authorization", auth);
                            reqst.AddParameter("undefined", "\n\n", ParameterType.RequestBody);
                            IRestResponse res = clntIt.Execute(reqst);
                            var gitbranChes = JsonConvert.DeserializeObject<List<Gitbranch>>(res.Content);

                            //  Console.WriteLine("Number of Branches in " + repo.name + " Repository :" + branChes.value.Count);
                            //  var gitbranchid = "";
                            var gitbranchname = "";
                        //for (int i=0;i<branChes.value.Count;i++)
                        //{
                            foreach (brancH Azurbranc in branChes.value)
                            {
                                Console.WriteLine("branch_name : " + Azurbranc.name + " & branch_id  :  " + Azurbranc);
                                //  gitbranchid = gitbranc.commit;
                                string[] brancname = Azurbranc.name.Split('/');
                                branchid = Azurbranc.objectId;

                            Gitbranches = gitbranChes.Where(x => x.name == brancname[2]).ToList();
                                if (Gitbranches.Count < 1)
                                {
                                //  Console.WriteLine("Create new branch on github");

                              

 // ******************  New Code For Get Master branch Sha_id from github 

                                string bseUrl = "https://api.github.com/repos/krishan-1991/AzureBackup/git/refs/heads/master";
                                    var clenT = new RestClient(bseUrl);
                                    var rqusT = new RestRequest(Method.GET);
                                    IRestResponse respnsE = clenT.Execute(rqusT);
                                    var mastrbrnchdetals = JsonConvert.DeserializeObject<MastrbrnchDetails>(respnsE.Content);

  ////******************* Code for Create a branch inside Github.  

                                    // var clients = new RestClient("https://api.github.com/repos/krishan-1991/demo/git/refs");
                                    var clients = new RestClient(gitbaseURL + "AzureBackup/git/refs");
                                    var requests = new RestRequest(Method.POST);
                                    requests.AddHeader("user-agent", "request");
                                    requests.AddHeader("content-type", "application/json");
                                    requests.AddHeader("authorization", "token 09939e9fb363e68a048bbabd9c6e23e13a01ca48");

                                   // string[] brancname = gitbranc.Select(x => x.name.Split('/');
                                    // requests.AddParameter("application/json", "{\n  \"ref\": \"refs/heads/krishantTestBranch\",\n  \"sha\": \"d80cc875918dfa93d31e8c0caee81abaecf4bf79\"\n}\n\t\n\t\n", ParameterType.RequestBody);

                                    requests.AddParameter("application/json", "{\n  \"ref\": \"" + Azurbranc.name + "\",\n  \"sha\": \"" + mastrbrnchdetals.objecT.sha + "\"\n}\n\t\n\t\n", ParameterType.RequestBody);
                                    IRestResponse objresponse = clients.Execute(requests);

                                ////End Code.   
                              
 //// New Code for get latest commits on a Latest branch (single branch).

                                Console.Write("Please Enter Branch_Id To Get Latest Commit : ");
                                //   var branchid = Console.ReadLine();
                                 var clientItek = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits/" + branchid + "? " + version);  // test for single commit 
                               // var clientItek = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits?searchCriteria.itemVersion.version=" + Azurbranc.name + "&" + version);  // test for single commit 

                                IRestResponse responseItek = clientItek.Execute(requestIte);
                                var LatestCommitk = JsonConvert.DeserializeObject<Latestcommit>(responseItek.Content);
                                Console.Write("\n\t Latest Commit Message : " + LatestCommitk.comment);
                                //   Console.Write("\n\t" + repo.name);


 //// New Code for download all Commited files filter by Commit id  on a Latest branch (single branch).

                                var clientItemsk = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits/" + LatestCommitk.commitId + "/changes?" + version);  // for get commited files
                               // var clientItefdk = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/items?recursionlevel=full&" + version);  // original code                 
                                var requestItemsk = new RestRequest(Method.GET);
                                requestItemsk.AddHeader("Authorization", auth);

                                IRestResponse responseItemsk = clientItemsk.Execute(requestItemsk);
                               // IRestResponse objresponseItemsk = clientItefdk.Execute(requestItemsk);
                                var commitedfilesk = JsonConvert.DeserializeObject<CommitedFiles>(responseItemsk.Content);
                               // Items itemsk = JsonConvert.DeserializeObject<Items>(objresponseItemsk.Content);

                                if (commitedfilesk.changes.Count > 0)
                                {
                                    var clientBlob = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/blobs?" + version);
                                    var requestBlob = new RestRequest(Method.POST);  // Add json body for send data
                                    requestBlob.AddJsonBody(commitedfilesk.changes.Where(it => it.item.gitObjectType == "blob").Select(it => it.item.objectId).ToList());
                                    requestBlob.AddHeader("Authorization", auth);
                                    requestBlob.AddHeader("Accept", "application/zip");
                                    clientBlob.DownloadData(requestBlob).SaveAs(FILE_PATH + project.name + "_" + repo.name + "_blob.zip");
                                    File.WriteAllText(FILE_PATH + project.name + "_" + repo.name + "_tree json", responseItemsk.Content);
                                    if (Array.Exists(args, argument => argument == "--unzip"))
                                    {
                                        if (Directory.Exists(FILE_PATH + project.name + "_" + repo.name)) Directory.Delete(FILE_PATH + project.name + "_" + repo.name, true);
                                        Directory.CreateDirectory(FILE_PATH + project.name + "_" + repo.name);
                                        fpath = FILE_PATH + project.name + "_" + repo.name;
                                        ZipArchive archive = ZipFile.OpenRead(FILE_PATH + project.name + "_" + repo.name + "_blob.zip");
                                        foreach (tsts test in commitedfilesk.changes)
                                            if (test.item.isFolder)
                                            {
                                                Directory.CreateDirectory(FILE_PATH + project.name + "_" + repo.name + test.item.path);
                                            }
                                            else
                                            {
                                                archive.GetEntry(test.item.objectId).ExtractToFile(FILE_PATH + project.name + "_" + repo.name + test.item.path, true);
                                            }
                                    }

                                    objprogram.Updatefile(LatestCommitk.comment, LatestCommitk.committer, fpath);
                                }

                            }
                            else
                            {
                                Console.WriteLine("not create new branch");

                            }

                        }

                        //}


                        // }

  ////Get all Repository from Github.

                        //////  var cli = new RestClient("https://api.github.com/users/krishan-1991/repos");
                        var cli = new RestClient(gitUrlrepo);
                        var req = new RestRequest(Method.GET);

                        req.AddHeader("content-type", "text/plain");
                        req.AddHeader("authorization", auth);
                        req.AddParameter("undefined", "\n\n", ParameterType.RequestBody);                    
                        IRestResponse respo = cli.Execute(req);
                        var gitrepos = JsonConvert.DeserializeObject<List<GitRepos>>(respo.Content);

                        ////  console.writeline("number of branches in " + repo.name + " repository :" + branches.value.count);
                        int gitrepos_id ;
                        var gitrepos_name = "";
                        foreach (GitRepos objgitrepos in gitrepos)
                        {
                            Console.WriteLine("repos_name : " + objgitrepos.name + " & repos_id  :  " + objgitrepos.id);
                            gitrepos_id = objgitrepos.id;
                            gitrepos_name = objgitrepos.name;

                        }


 ////// Get all branch from Github Repository.

 //                        var clntIt = new RestClient(gitbaseURL+ "AzureBackup/branches");
 //                         var reqst = new RestRequest(Method.GET);                      
 //                         reqst.AddHeader("Content-Type", "text/plain");
 //                         reqst.AddHeader("Authorization", auth);
 //                         reqst.AddParameter("undefined", "\n\n", ParameterType.RequestBody);
 //                         IRestResponse res= clntIt.Execute(reqst);
 //                         var gitbranChes = JsonConvert.DeserializeObject<List<Gitbranch>>(res.Content);

 //                       //  Console.WriteLine("Number of Branches in " + repo.name + " Repository :" + branChes.value.Count);
 //                       //  var gitbranchid = "";
 //                       var gitbranchname = "";
 //                       foreach (Gitbranch gitbranc in gitbranChes)
 //                       {
 //                           Console.WriteLine("branch_name : " + gitbranc.name + " & branch_id  :  " + gitbranc.commit);
 //                           //  gitbranchid = gitbranc.commit;
 //                           gitbranchname = gitbranc.name;

 //                       }


 ////// New Code for get latest commits on a Latest branch (single branch).

 //                       Console.Write("Please Enter Branch_Id To Get Latest Commit : ");
 //                    //   var branchid = Console.ReadLine();
 //                       var clientIte = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits/" + branchid + "? " + version);  // test for single commit 

 //                       IRestResponse responseIte = clientIte.Execute(requestIte);             
 //                       var LatestCommit = JsonConvert.DeserializeObject<Latestcommit>(responseIte.Content);                  
 //                       Console.Write("\n\t Latest Commit Message : " + LatestCommit.comment);
 //                       //   Console.Write("\n\t" + repo.name);


 ////// New Code for download all Commited files filter by Commit id  on a Latest branch (single branch).

 //                       var clientItems = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits/" + LatestCommit.commitId + "/changes?" + version);  // for get commited files
 //                       var clientItefd = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/items?recursionlevel=full&" + version);  // original code                 
 //                       var requestItems = new RestRequest(Method.GET);
 //                       requestItems.AddHeader("Authorization", auth);

 //                       IRestResponse responseItems = clientItems.Execute(requestItems); 
 //                       IRestResponse objresponseItems = clientItefd.Execute(requestItems); 
 //                       var commitedfiles = JsonConvert.DeserializeObject<CommitedFiles>(responseItems.Content); 
 //                       Items items = JsonConvert.DeserializeObject<Items>(objresponseItems.Content);

 //                       if (commitedfiles.changes.Count > 0) 
 //                       {
 //                           var clientBlob = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/blobs?" + version);
 //                           var requestBlob = new RestRequest(Method.POST);  // Add json body for send data
 //                           requestBlob.AddJsonBody(commitedfiles.changes.Where(it => it.item.gitObjectType == "blob").Select(it => it.item.objectId).ToList());
 //                           requestBlob.AddHeader("Authorization", auth);
 //                           requestBlob.AddHeader("Accept", "application/zip");
 //                           clientBlob.DownloadData(requestBlob).SaveAs(FILE_PATH + project.name + "_" + repo.name + "_blob.zip");
 //                           File.WriteAllText(FILE_PATH + project.name + "_" + repo.name +  "_tree json", responseItems.Content);
 //                           if (Array.Exists(args, argument => argument == "--unzip"))
 //                           {
 //                               if (Directory.Exists(FILE_PATH + project.name + "_" + repo.name )) Directory.Delete(FILE_PATH + project.name + "_" + repo.name , true);
 //                               Directory.CreateDirectory(FILE_PATH + project.name + "_" + repo.name);
 //                               fpath = FILE_PATH + project.name + "_" + repo.name;
 //                               ZipArchive archive = ZipFile.OpenRead(FILE_PATH + project.name + "_" + repo.name + "_blob.zip");
 //                               foreach (tsts test in commitedfiles.changes)
 //                                   if (test.item.isFolder)
 //                                   {
 //                                       Directory.CreateDirectory(FILE_PATH + project.name + "_" + repo.name + test.item.path);
 //                                   }
 //                                   else
 //                                   {
 //                                       archive.GetEntry(test.item.objectId).ExtractToFile(FILE_PATH + project.name + "_" + repo.name + test.item.path, true);
 //                                   }
 //                           }

 //                           objprogram.Updatefile(LatestCommit.comment, LatestCommit.committer,fpath);
 //                       }

      

  //// 1st new code get all branches (counts) commit.
  
                        var clientItemss = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits?&" + version);
                        //  var clientItems = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits?fromcommitid=52e75ea20cd02d142a0e920914a07daf1de5b927&" + version);

                        var requestItemss = new RestRequest(Method.GET);
                        requestItemss.AddHeader("Authorization", auth);
                        IRestResponse responseItemss = clientItemss.Execute(requestItemss);
                        Items itemssc = JsonConvert.DeserializeObject<Items>(responseItemss.Content);


                        //var objclientIte = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits?searchCriteria.itemVersion.version=" + branchname + "&" + version);  // test fo all commit 
                        //IRestResponse respnseIte = objclientIte.Execute(requestIte);                

                        //var allcommit = JsonConvert.DeserializeObject<AllCommit>(respnseIte.Content);  
                        //Console.WriteLine("Total Commits : " + allcommit.count);

 //// 2nd new code download the code based on commit id. 
 ///
                        //if (allcommit.count > 0)
                        if (itemssc.count > 0)
                        {
                            //  foreach (Commit itm in allcommit.value)
                            foreach (Item itm in itemssc.value) 
                            {
                                                      
                                var clientItms = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/commits/" + itm.commitId + "/changes? " + version);
                                var requestItms = new RestRequest(Method.GET);
                                requestItms.AddHeader("Authorization", auth);

                                IRestResponse responseItms = clientItms.Execute(requestItms); 
                                //  IRestResponse responseItems = clientItemss.Execute(requestItems); 
                                var commitedFiles = JsonConvert.DeserializeObject<CommitedFiles>(responseItms.Content); 
                                Items itms = JsonConvert.DeserializeObject<Items>(responseItms.Content);
                                Console.Write(" - " + itms.count + "\n");

                                if (commitedFiles.changes.Count > 0)  
                                {
                                    var clientBlob = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/blobs?" + version);
                                    var requestBlob = new RestRequest(Method.POST);  
                                    requestBlob.AddJsonBody(commitedFiles.changes.Where(it => it.item.gitObjectType == "blob").Select(it => it.item.objectId).ToList());
                                    requestBlob.AddHeader("Authorization", auth);
                                    requestBlob.AddHeader("Accept", "application/zip");
                                    clientBlob.DownloadData(requestBlob).SaveAs(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId + "_blob.zip");
                                    File.WriteAllText(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId + "_tree json", responseItms.Content);
                                    if (Array.Exists(args, argument => argument == "--unzip"))
                                    {
                                        if (Directory.Exists(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId)) Directory.Delete(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId, true);
                                        Directory.CreateDirectory(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId);
                                        spath = sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId;
                                        ZipArchive archive = ZipFile.OpenRead(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId + "_blob.zip");
                                        foreach (tsts test in commitedFiles.changes)
                                            if (test.item.isFolder)
                                            {
                                                Directory.CreateDirectory(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId + test.item.path);
                                            }
                                            else
                                            {
                                                archive.GetEntry(test.item.objectId).ExtractToFile(sFILE_PATH + project.name + "_" + repo.name + "_" + itm.commitId + test.item.path, true);
                                            }
                                    }
                                  //  objprogram.Updatefile(LatestCommit.comment, LatestCommit.committer, Azurebranchname, spath);
                                }
                                
                           }
                      }

                   ////Code for Download Whole Project.

                                if (items.count > 0)
                                {
                                    var clientBlob = new RestClient(baseURL + "_apis/git/repositories/" + repo.id + "/blobs?" + version);
                                    var requestBlob = new RestRequest(Method.POST);
                                    requestBlob.AddJsonBody(items.value.Where(itm => itm.gitObjectType == "blob").Select(itm => itm.objectId).ToList());
                                    requestBlob.AddHeader("Authorization", auth);
                                    requestBlob.AddHeader("Accept", "application/zip");
                                    clientBlob.DownloadData(requestBlob).SaveAs(outDir + project.name + "_" + repo.name + "_blob.zip");
                                    File.WriteAllText(outDir + project.name + "_" + repo.name + "_tree.json", responseItems.Content);
                                    if (Array.Exists(args, argument => argument == "--unzip"))
                                    {
                                        if (Directory.Exists(outDir + project.name + "_" + repo.name)) Directory.Delete(outDir + project.name + "_" + repo.name, true);
                                        Directory.CreateDirectory(outDir + project.name + "_" + repo.name);
                                        pathh = outDir + project.name + "_" + repo.name ;
                                        ZipArchive archive = ZipFile.OpenRead(outDir + project.name + "_" + repo.name + "_blob.zip");
                                        foreach (Item item in items.value)
                                            if (item.isFolder)
                                            {
                                                Directory.CreateDirectory(outDir + project.name + "_" + repo.name + item.path);

                                            }
                                            else
                                            {
                                                archive.GetEntry(item.objectId).ExtractToFile(outDir + project.name + "_" + repo.name + item.path, true);
                                            }
                                    }

                           // objprogram.Updatefile(LatestCommit.comment, LatestCommit.committer, Azurebranchname, pathh);
                        }
                    }
                        }
                    }
                    //  objprogram.Updatefile();
                    Console.ReadLine();

                }

      


    }
}