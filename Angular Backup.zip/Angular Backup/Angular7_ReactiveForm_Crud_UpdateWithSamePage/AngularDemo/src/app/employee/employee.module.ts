import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeRoutingModule } from './employee-routing.module';
import { EmployeeComponent } from './employee.component';

import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { FormsModule } from '@angular/forms';  //use for create Template Driven Form page.
import { ReactiveFormsModule } from '@angular/forms'; //use for create Reactive Forms Module or Model driven form page.

 import { FileUploader, FileLikeObject } from 'ng2-file-upload';



@NgModule({
  declarations: [EmployeeComponent,
    
    ],
  imports: [
    AngularMultiSelectModule,
    FormsModule, 
    ReactiveFormsModule,
    CommonModule,
    EmployeeRoutingModule //,FileUploader,FileLikeObject
  ]
})
export class EmployeeModule { }
