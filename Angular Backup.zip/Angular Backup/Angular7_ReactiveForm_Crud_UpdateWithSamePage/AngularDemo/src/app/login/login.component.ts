import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  
import { EmployeeDataService } from '../Services/EmployeeDataService';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
    providers:[EmployeeDataService]
})
export class LoginComponent implements OnInit {

//constructor() { }
  constructor(private dataservice: EmployeeDataService,private route:Router) { }

  ngOnInit() {
  }

  
Login={
  email:"",
  password:""
  
 }
  onClickloginSubmit(LoginData){

let log ={
  Email: LoginData.email,
  Password: LoginData.password
}
    
    console.log(LoginData,log,"LoginDatakk")
    this.dataservice.CheckAuthByUserName_pwd(log).subscribe(res=>{
      if(res)
      {
        console.log(res,this.route);
        this.route.navigate(['/employee']);
     alert("Login User Successfully!!!");

      }
      else {
        alert("Invalid username and Password");
      }
    // task for suceess
    },err=>{
    // task for failure
    })
    
  }

}
