
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  
import { EmployeeDataService } from '../Services/EmployeeDataService';

 import { FileUploader, FileLikeObject } from 'ng2-file-upload';


import { FormControl } from '@angular/forms';            //this namespsce use for create Template Driven Form page.
import { FormGroup } from '@angular/forms';              //this namespsce use for Reactive Forms Module or Model driven form page.
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[EmployeeDataService]
})
export class EmployeeComponent implements OnInit {
 

  
// ////use for create Template Driven Form page.
//   //  onClickSubmit(form){
//   //   console.log("form", form);
    
//   // }

//   ////use for Reactive Forms Module or Model driven form page.
//    onClickSubmit(data) {
//      this.emailid = data.emailid;
//   } 

//=====================

dataSaved = false;

    employeeForm: any;
    allEmployees: any=[];
    countryData:any=[];
    State: any=[];
    City:any=[];

    employeeIdUpdate = null;
    massage = null;

employee={
  name:"",country:"",state:"",city: "",address:"",phone:"",remarks:"", pin:"",email:"",Status:"",
 date :"",
 gender:"",
password:"",
 Hobbies:""

}
empid:any;
Chklst_dropdownList:any=[];
Chklst_selectedItems :any=[];
Chklst_dropdownSettings = {};
hobbiesArr:any =[];
setHobbies:any =[];
isEdit:boolean =false;
// dropdownList = [];
// selectedItems = [];
// dropdownSettings = {};

  
    constructor(private dataservice: EmployeeDataService,private route:Router) { }
   //constructor(){}
    ngOnInit() {
this.getEmployee();
this.GetCountry();
this.GetHobbies();

this.Chklst_dropdownSettings = { 
  singleSelection: false, 
  text:"Select Hobbies",
  selectAllText:'Select All',
  unSelectAllText:'UnSelect All',
  enableSearchFilter: true,
  classes:"myclass custom-class"
};  
    }

  //  ////file upload work start

  //   public uploader: FileUploader = new FileUploader({
  //     url: URL,
  //     disableMultipart : false,
  //     autoUpload: true,
  //     method: 'post',
  //     itemAlias: 'attachment',
  //     allowedFileType: ['image', 'pdf']
  
  
  //     });
  

  //   public onFileSelected(event: EventEmitter<File[]>) {
  //     const file: File = event[0];
  //     console.log(file);
  
  //   }

 ////file upload work end

////Checkboxlist work start


GetHobbies(){
  this.dataservice.GetHobbies().subscribe(res=>{
    if(res){
          this.Chklst_dropdownList = res;
     let test = this.Chklst_dropdownList.map(function(obj) { 
        obj['itemName'] = obj['Hobbies_Name'];
        obj['id'] = obj['pkHobbies_Id'];
        delete obj['Hobbies_Name'];
        delete obj['pkHobbies_Id'];
        return obj; 
    }); 

    this.setHobbies = test;
    }
  
    },err=>{
    // task for failure
    })
  }

    onItemSelect(item:any){
   this.hobbiesArr.push(item.itemName);
    }
    OnItemDeSelect(item:any){
      console.log(item);
      console.log(this.Chklst_selectedItems);
    }
    onSelectAll(items: any){
      console.log(items);
    }
    onDeSelectAll(items: any){
      console.log(items);
    }


   ////Checkboxlist work End

    getEmployee(){
      this.dataservice.getEmployee().subscribe(res=>{
        if(res){
this.allEmployees =res;

        }
      // console.log(JSON.stringify(res));
        },err=>{
        // task for failure
        })

      }

      GetCountry(){
      this.dataservice.GetCountry().subscribe(res=>{
        if(res){
          this.countryData = res;
        }
       
       console.log(JSON.stringify(res));
      
        },err=>{
        // task for failure
        })
      }

//       fillState(data){
// this.State = this.State.filter(state=>{
//   return state.pkState_Id == data.pkCountry_Id
// })
// console.log(this.State,"oo");
//       }

Edit_Employee(empid)
{
  this.isEdit=true;
  this.dataservice.Edit_Employee(empid).subscribe(res=>{
    if(res){ 
      
      console.log(res[0],"emppkk");
      this.empid =res[0].EmpId,
       this.employee.name =res[0].EmpName,
       this.employee.country= res[0].Country_Id,
      // this.employee.state=  "up",
       this.employee.state=  res[0].State_Id,
       this.employee.city=  res[0].City_Id,
       this.employee.address=  res[0].Address,
       this.employee.phone=  res[0].MobileNo,
       this.employee.remarks=  res[0].Remark,
       this.employee.pin=  res[0].PinNo,
       this.employee.email=  res[0].Email,
       this.employee.password=  res[0].Password,
       this.employee.Hobbies=  res[0].Hobbies,
       this.employee.Status=  res[0].Status,
     //  this.employee.date=  '2012-10-02',
      this.employee.date=  res[0].JoinDate.split(" ")[0].split("/").reverse().join("-"),    
       this.employee.gender=  res[0].Gender
       let hob = res[0].Hobbies.split(",");
       console.log(hob,this.setHobbies);
       this.Chklst_selectedItems =[];
       for(let i=0; i< this.setHobbies.length; i++){
        for(let j=0; j< hob.length; j++){
          if(this.setHobbies[i].itemName == hob[j]){
            this.Chklst_selectedItems.push(this.setHobbies[i]);
          }
        }
      }
//this.Chklst_selectedItems =[{itemName: "Cricket", id: 1}];
      console.log(res,"hobbjhbjies",this.empid);
      console.log(this.Chklst_selectedItems, "cc");
    }
    },err=>{
    // task for failure
    })
}


onClickupdateEmployee(employeeData,employeeForm){
  console.log(this.empid);
  let empData = {
  EmpId:this.empid,
  EmpName:employeeData.name,
  Country_Id:employeeData.country,
  State_Id:employeeData.state,
  City_Id:employeeData.city,
  Address:employeeData.address,
  MobileNo:employeeData.phone,
  Remark:employeeData.remarks,
  Gender:employeeData.gender,
  PinNo:employeeData.pin,
  Email:employeeData.email,
  Hobbies: this.Chklst_selectedItems.map(item=>{return item.itemName}).join(","),
  Status:employeeData.Status,
  Password:employeeData.password,
  JoinDate:employeeData.date
  }
  
   console.log(empData,"empData");
  this.dataservice.updateEmployee(empData).subscribe(res=>{
  // task for suceess
  if(res){
    this.isEdit =false;
    this.getEmployee();
    employeeForm.reset();
  }
  console.log(JSON.stringify(res));
 
  },err=>{
  // task for failure
  })
   
     }
     

      GetState(data){
       // console.log(this.employee.country);
      //  let stateObj = this.countryData.filter(item=>{
      //    return item.Country_Name == data;
      // })
      //   this.dataservice.GetState(stateObj[0].pkCountry_Id).subscribe(res=>{
        console.log(data.target.value);
         let country_id = data.target.value.split(" ")[1];
          this.dataservice.GetState(country_id).subscribe(res=>{
          if(res){
            this.State = res;
            console.log(JSON.stringify(res));
          }
           
          },err=>{
          // task for failure
          })
  
        }
        GetCity(data){
          let state_id = data.target.value.split(" ")[1];
        //   let cityObj = this.State.filter(item=>{
        //     return item.State_Name == data;
        //  })

          this.dataservice.GetCity(state_id).subscribe(res=>{
            if(res){
              this.City = res;
            }
           console.log(JSON.stringify(res));
          
            },err=>{
            // task for failure
            })
    
          }
        
        
      Delete_Employee(data){
              this.dataservice.deleteEmployee(data).subscribe(res=>{
                if(res){
                  this.getEmployee();
                }
      // task for suceess
      console.log(JSON.stringify(res));
      },err=>{
      // task for failure
      })
          }
//// 1st method get form value.
  onClickSubmit(employeeData,employeeForm){
let empData = {
EmpName:employeeData.name,
Country_Id:employeeData.country,
State_Id:employeeData.state,
City_Id:employeeData.city,
Address:employeeData.address,
MobileNo:employeeData.phone,
Remark:employeeData.remarks,
Gender:employeeData.gender,
PinNo:employeeData.pin,
Email:employeeData.email,
Hobbies:this.Chklst_selectedItems.map(item=>{return item.itemName}).join(","),
Status:employeeData.Status,
Password:employeeData.password,
JoinDate:employeeData.date
}
//// 2nd method get form value.
     // onClickSubmit(form){
    //  let empData ={
    //    "name":form.value.name,
    //  }

console.log(empData,"kktest");
this.dataservice.addEmployee(empData).subscribe(res=>{
  if(res){
    // this.Chklst_selectedItems=[];
    this.getEmployee();
    employeeForm.reset();
  }
  console.log(res,"kktestres");
// task for suceess
console.log(JSON.stringify(res));
},err=>{
// task for failure
})



    //  if (form.value.EmployeeID == null) {
    //   this.dataservce.AddEmployee(form.value)
    //     .subscribe(data => {
    //       this.resetForm(form);
    //       this.dataservce.getEmployee();
    //       this.toastr.success('New Record Added Succcessfully', 'Employee Register');
    //     })
    // }
    // else{
    //   this.dataservce.EditEmployee(form.value.EmployeeID, form.value)
    //   .subscribe(data => {
    //     this.resetForm(form);
    //     this.dataservce.getEmployee();
    //     this.toastr.info('Record Updated Successfully!', 'Employee Register');
    //   });

    // }
   }

}
