
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  
import { EmployeeDataService } from '../Services/EmployeeDataService';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

 import { FileUploader, FileLikeObject } from 'ng2-file-upload';


import { FormControl } from '@angular/forms';            //this namespsce use for create Template Driven Form page.
              //this namespsce use for Reactive Forms Module or Model driven form page.
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[EmployeeDataService]
})
export class EmployeeComponent implements OnInit {
 
registerForm: FormGroup;
registerFormUpdate: FormGroup;
dataSaved = false;

    employeeForm: any;
    allEmployees: any=[];

    countryData:any=[];
    State: any=[];
    City:any=[];

    employeeIdUpdate = null;
    massage = null;


empid:any;
Chklst_dropdownList:any=[];
Chklst_selectedItems :any=[];
ObjModalChklst_selectedItems :any=[];
Chklst_dropdownSettings = {};
hobbiesArr:any =[];
setHobbies:any =[];
isEdit:boolean =false;


  
    constructor(private dataservice: EmployeeDataService,private route:Router,
      private formBuilder: FormBuilder) { }
  
    ngOnInit() {
      this.registerForm = this.formBuilder.group({
        EmpName: ['',Validators.required],
        Address: [''],
        MobileNo: ['',Validators.required],
        Remark: [''],
        PinNo: [''],
        Email: ['',[Validators.required, Validators.email]],
        Password: ['',[Validators.required, Validators.minLength(8)]],
        JoinDate: [''],
        Gender: ['M'],
        Country_Id: ['',Validators.required],
        State_Id: ['',Validators.required],
        City_Id: ['',Validators.required],
        Status: [''],
        Hobbies: ['']
       
    });


    this.registerFormUpdate = this.formBuilder.group({
      EmpNames: ['',Validators.required],
      Addresss: [''],
      MobileNos: ['',Validators.required],
      Remarks: [''],
      PinNos: [''],
      Emails: ['',[Validators.required, Validators.email]],
      Passwords: ['',[Validators.required, Validators.minLength(8)]],
      JoinDates: [''],
      Genders: [''],
      Country_Ids: ['',Validators.required],
      State_Ids: ['',Validators.required],
      City_Ids: ['',Validators.required],
      Statuss: [''],
      Hobbiess: ['']
     
  });

this.getEmployee();
this.GetCountry();
this.GetHobbies();

this.Chklst_dropdownSettings = { 
  singleSelection: false, 
  text:"Select Hobbies",
  selectAllText:'Select All',
  unSelectAllText:'UnSelect All',
  enableSearchFilter: true,
  classes:"myclass custom-class"
};  

    }


    get f() { return this.registerForm.controls; }
    
    get f1() { return this.registerFormUpdate.controls; }

  //  ////file upload work start

  //   public uploader: FileUploader = new FileUploader({
  //     url: URL,
  //     disableMultipart : false,
  //     autoUpload: true,
  //     method: 'post',
  //     itemAlias: 'attachment',
  //     allowedFileType: ['image', 'pdf']
  
  
  //     });
  

  //   public onFileSelected(event: EventEmitter<File[]>) {
  //     const file: File = event[0];
  //     console.log(file);
  
  //   }

 ////file upload work end

////Checkboxlist work start


GetHobbies(){
  this.dataservice.GetHobbies().subscribe(res=>{
    if(res){
          this.Chklst_dropdownList = res;
          console.log(this.Chklst_dropdownList,"ggg")
     let test = this.Chklst_dropdownList.map(function(obj) { 
        obj['itemName'] = obj['Hobbies_Name'];
        obj['id'] = obj['pkHobbies_Id'];
        delete obj['Hobbies_Name'];
        delete obj['pkHobbies_Id'];
        return obj; 
    }); 

    this.setHobbies = test;
    }
  
    },err=>{
    // task for failure
    })
  }

  onClickSubmit2(){
    let empData = {
      EmpName:this.registerForm.controls['EmpName'].value,
      Address:this.registerForm.controls['Address'].value,
      MobileNo:this.registerForm.controls['MobileNo'].value,
      Remark:this.registerForm.controls['Remark'].value,
      PinNo:this.registerForm.controls['PinNo'].value,
      Email:this.registerForm.controls['Email'].value,
      Password:this.registerForm.controls['Password'].value,
      Gender:this.registerForm.controls['Gender'].value,
      JoinDate:this.registerForm.controls['JoinDate'].value,
      Country_Id:this.registerForm.controls['Country_Id'].value,
      Hobbies:this.registerForm.controls['Hobbies'].value.map(item=>{return item.itemName}).join(","),
      Status:this.registerForm.controls['Status'].value,
      State_Id:this.registerForm.controls['State_Id'].value,
      City_Id:this.registerForm.controls['City_Id'].value
      }
  
    console.log(empData,"reg",this.registerForm)
    //this.Chklst_selectedItems.map(item=>{return item.itemName}).join(",")
    this.dataservice.addEmployee(empData).subscribe(res=>{
      if(res){
        // this.Chklst_selectedItems=[];
        this.getEmployee();
        this.registerForm.reset();
      }
      console.log(res,"kktestres");
    // task for suceess
    console.log(JSON.stringify(res));
    },err=>{
    // task for failure
    })
  }

    onItemSelect(item:any){
   this.hobbiesArr.push(item.itemName);
   console.log(this.hobbiesArr);
    }
    OnItemDeSelect(item:any){
      console.log(item);
      console.log(this.Chklst_selectedItems);
    }
    onSelectAll(items: any){
      console.log(items);
    }
    onDeSelectAll(items: any){
      console.log(items);
    }


   ////Checkboxlist work End

    getEmployee(){
      this.dataservice.getEmployee().subscribe(res=>{
        if(res){
this.allEmployees =res;

        }
       console.log(JSON.stringify(res),"get kk");
        },err=>{
        // task for failure
        })

      }

      GetCountry(){
      this.dataservice.GetCountry().subscribe(res=>{
        if(res){
          this.countryData = res;
        }
       
       console.log(JSON.stringify(res));
      
        },err=>{
        // task for failure
        })
      }



Edit_Employee(empid)
{
  this.isEdit=true;
  this.dataservice.Edit_Employee(empid).subscribe(res=>{ 
    console.log(res,"kk",empid);
    if(res){ 
     
    // this.registerForm.controls['EmpName'].setValue(res[0].EmpName),
    //     this.registerForm.controls['Address'].setValue(res[0].Address),
    //     this.registerForm.controls['MobileNo'].setValue(res[0].MobileNo),
    //     this.registerForm.controls['Remark'].setValue(res[0].Remark),
    //     this.registerForm.controls['PinNo'].setValue(res[0].PinNo),
    //     this.registerForm.controls['Email'].setValue(res[0].Email),
    //     this.registerForm.controls['Password'].setValue(res[0].Password),
    //     this.registerForm.controls['Gender'].setValue(res[0].Gender),
    //     this.registerForm.controls['JoinDate'].setValue(res[0].JoinDate.split(" ")[0].split("/").reverse().join("-")),
    //     this.registerForm.controls['Country_Id'].setValue(res[0].Country_Id),
    //     this.registerForm.controls['Status'].setValue(res[0].Status),
    //     this.registerForm.controls['State_Id'].setValue(res[0].State_Id),
    //     this.registerForm.controls['City_Id'].setValue(res[0].City_Id),
    //   //this.registerForm.patchValue(res[0]);
  

    this.registerFormUpdate.controls['EmpNames'].setValue(res[0].EmpName),
    this.registerFormUpdate.controls['Addresss'].setValue(res[0].Address),
    this.registerFormUpdate.controls['MobileNos'].setValue(res[0].MobileNo),
    this.registerFormUpdate.controls['Remarks'].setValue(res[0].Remark),
    this.registerFormUpdate.controls['PinNos'].setValue(res[0].PinNo),
    this.registerFormUpdate.controls['Emails'].setValue(res[0].Email),
    this.registerFormUpdate.controls['Passwords'].setValue(res[0].Password),
    this.registerFormUpdate.controls['Genders'].setValue(res[0].Gender),
    this.registerFormUpdate.controls['JoinDates'].setValue(res[0].JoinDate.split(" ")[0].split("/").reverse().join("-")),
    this.registerFormUpdate.controls['Country_Ids'].setValue(res[0].Country_Id),
    this.registerFormUpdate.controls['Statuss'].setValue(res[0].Status),
    this.registerFormUpdate.controls['State_Ids'].setValue(res[0].State_Id),
    this.registerFormUpdate.controls['City_Ids'].setValue(res[0].City_Id),
  //this.registerForm.patchValue(res[0]);

      console.log(res[0],"emppkk");
     this.empid =res[0].EmpId;
      
       let hob = res[0].Hobbies.split(",");
       console.log(hob,this.setHobbies);
      // this.Chklst_selectedItems =[];
      this.ObjModalChklst_selectedItems =[];  
       for(let i=0; i< this.setHobbies.length; i++){
        for(let j=0; j< hob.length; j++){
          if(this.setHobbies[i].itemName == hob[j]){
           // this.Chklst_selectedItems.push(this.setHobbies[i]);
           this.ObjModalChklst_selectedItems.push(this.setHobbies[i]);
          }
        }
      }
      // this.registerForm.controls['Hobbies'].setValue(this.ObjModalChklst_selectedItems),
      this.registerFormUpdate.controls['Hobbiess'].setValue(this.ObjModalChklst_selectedItems),

//this.Chklst_selectedItems =[{itemName: "Cricket", id: 1}];
      console.log(res,"hobbjhbjies",this.empid);
      console.log(this.ObjModalChklst_selectedItems, "cc");
    }
    },err=>{
    // task for failure
    })
}


onClickupdateEmployee(){
  console.log(this.empid,"EEEEE");
  let empData = {
    // EmpName:this.registerForm.controls['EmpName'].value,
    // Address:this.registerForm.controls['Address'].value,
    // MobileNo:this.registerForm.controls['MobileNo'].value,
    // Remark:this.registerForm.controls['Remark'].value,
    // PinNo:this.registerForm.controls['PinNo'].value,
    // Email:this.registerForm.controls['Email'].value,
    // Password:this.registerForm.controls['Password'].value,
    // Gender:this.registerForm.controls['Gender'].value,
    // JoinDate:this.registerForm.controls['JoinDate'].value,
    // Country_Id:this.registerForm.controls['Country_Id'].value,
    // Hobbies:this.registerForm.controls['Hobbies'].value.map(item=>{return item.itemName}).join(","),
    // Status:this.registerForm.controls['Status'].value,
    // State_Id:this.registerForm.controls['State_Id'].value,
    // City_Id:this.registerForm.controls['City_Id'].value


    EmpName:this.registerFormUpdate.controls['EmpNames'].value,
    Address:this.registerFormUpdate.controls['Addresss'].value,
    MobileNo:this.registerFormUpdate.controls['MobileNos'].value,
    Remark:this.registerFormUpdate.controls['Remarks'].value,
    PinNo:this.registerFormUpdate.controls['PinNos'].value,
    Email:this.registerFormUpdate.controls['Emails'].value,
    Password:this.registerFormUpdate.controls['Passwords'].value,
    Gender:this.registerFormUpdate.controls['Genders'].value,
    JoinDate:this.registerFormUpdate.controls['JoinDates'].value,
    Country_Id:this.registerFormUpdate.controls['Country_Ids'].value,
    Hobbies:this.registerFormUpdate.controls['Hobbiess'].value.map(item=>{return item.itemName}).join(","),
    Status:this.registerFormUpdate.controls['Statuss'].value,
    State_Id:this.registerFormUpdate.controls['State_Ids'].value,
    City_Id:this.registerFormUpdate.controls['City_Ids'].value

    }

 empData['EmpId'] = this.empid;

   console.log(empData,"empData");

  this.dataservice.updateEmployee(empData).subscribe(res=>{
  // task for suceess
  if(res){
    this.isEdit =false;
    this.getEmployee();
   // this.registerForm.reset();
   this.registerFormUpdate.reset();
  }
  console.log(JSON.stringify(res));
 
  },err=>{
  // task for failure
  })
   
     }
     
     GetState2(data){
       console.log(data.target.value);
       let country_id = data.target.value.split(" ")[1];
 
 this.dataservice.GetState(country_id).subscribe(res=>{
   if(res){
     this.State = res;
     console.log(JSON.stringify(res));
   }
    
   },err=>{
   // task for failure
   })

     }

  
        GetCity2(data){
          console.log(data.target.value,"sdgs");
          let state_id = data.target.value.split(" ")[1];
         this.dataservice.GetCity(state_id).subscribe(res=>{
          if(res){
            this.City = res;
          }
         
         console.log(JSON.stringify(res));
        
          },err=>{
          // task for failure
          })
       
               }

         
      Delete_Employee(data){
              this.dataservice.deleteEmployee(data).subscribe(res=>{
                if(res){
                  this.getEmployee();
                }
      // task for suceess
      console.log(JSON.stringify(res));
      },err=>{
      // task for failure
      })
          }




}
