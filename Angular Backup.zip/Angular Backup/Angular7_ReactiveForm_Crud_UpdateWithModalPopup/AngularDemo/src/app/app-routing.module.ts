import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [{ path: 'order-list', loadChildren: () => import('./orders/orders.module').then(m => m.OrdersModule) },
 { path: '', loadChildren: () => import('./employee/employee.module').then(m => m.EmployeeModule) }, 
 { path: 'employee', loadChildren: () => import('./employee/employee.module').then(m => m.EmployeeModule) },
 { path: 'employee-list', loadChildren: () => import('./employee-list/employee-list.module').then(m => m.EmployeeListModule) },
 { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
