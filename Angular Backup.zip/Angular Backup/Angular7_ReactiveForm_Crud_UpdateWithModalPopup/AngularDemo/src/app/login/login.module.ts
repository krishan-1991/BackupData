import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';


import { FormsModule } from '@angular/forms';  //use for create Template Driven Form page.
import { ReactiveFormsModule } from '@angular/forms'; //use for create Reactive Forms Module or Model driven form page.




@NgModule({
  declarations: [LoginComponent],
  imports: [
    FormsModule, 
    ReactiveFormsModule,
    CommonModule,
    LoginRoutingModule
  ]
})
export class LoginModule { }
