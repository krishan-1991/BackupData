
import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders,HttpRequest,HttpParams } from '@angular/common/http';

// import { HttpService } from './http.service';


@Injectable()
export class EmployeeDataService {
 // constructor(private httpClient: HttpClient,private httpService: HttpService) {
    constructor(private httpClient: HttpClient) {
  }

  addEmployee(formData){
      console.log(formData);
      return this.httpClient.post("http://localhost:54336/Api/Values/AddEmployee", formData);
  }

  deleteEmployee(employeeId){
    return this.httpClient.delete("http://localhost:54336/Api/Values/EmployeeDelete/"+ employeeId);
}
Edit_Employee(employeeId){
    return this.httpClient.get("http://localhost:54336/Api/Values/GetEmployeeByID/"+ employeeId);
}

updateEmployee(formData){
    return this.httpClient.put("http://localhost:54336/Api/Values/EditEmployee", formData);
}


getEmployee(){  
    return this.httpClient.get("http://localhost:54336/Api/Values/GetEmployee");
}
GetCountry(){
    return this.httpClient.get("http://localhost:54336/Api/Values/GetCountry");
}

GetState(countryId){  
    return this.httpClient.get("http://localhost:54336/Api/Values/GetState/" + countryId);
}

GetCity(stateid){  
    return this.httpClient.get("http://localhost:54336/Api/Values/GetCity/"+stateid);
}
getEmployeeById(employeeId){
    return this.httpClient.get("apiurl", employeeId);
}

CheckAuthByUserName_pwd(LoginData){
    return this.httpClient.post("http://localhost:54336/Api/Values/UserAuthentication", LoginData);
}

////Checkboxlist work start
GetHobbies(){
    return this.httpClient.get("http://localhost:54336/Api/Values/GetHobbies");
}

////Checkboxlist work end

//   getEmployee() {  
//     return this.http.get<Employee[]>(ROOT_URL + 'Employees');  
//   }  
}