
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  
import { EmployeeDataService } from '../Services/EmployeeDataService';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { FileUploader, FileLikeObject } from 'ng2-file-upload';

import { FormControl } from '@angular/forms';            //this namespsce use for create Template Driven Form page.
              //this namespsce use for Reactive Forms Module or Model driven form page.
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[EmployeeDataService]
})
export class EmployeeComponent implements OnInit {
 
registerForm: FormGroup;
registerFormUpdate: FormGroup;
dataSaved = false;

    employeeForm: any;
    allEmployees: any=[];
   
    countryData:any=[];
    State: any=[];
    City:any=[];

    employeeIdUpdate = null;
    massage = null;


empid:any;
Chklst_dropdownList:any=[];
Chklst_selectedItems :any=[];
ObjModalChklst_selectedItems :any=[];
Chklst_dropdownSettings = {};
hobbiesArr:any =[];
setHobbies:any =[];

rowIndex = null;
isEdit:boolean =false;
showMessage:boolean=false;

  
    constructor(private dataservice: EmployeeDataService,private route:Router,
      private formBuilder: FormBuilder) { }
  
    ngOnInit() {
      this.registerForm = this.formBuilder.group({
        EmpName: ['',Validators.required],
        Address: [''],
        MobileNo: ['',Validators.required],
        Remark: [''],
        PinNo: [''],
        Email: ['',[Validators.required, Validators.email]],
        Password: ['',[Validators.required, Validators.minLength(8)]],
        JoinDate: [''],
        Gender: ['M'],
        Country_Id: ['',Validators.required],
        State_Id: ['',Validators.required],
        City_Id: ['',Validators.required],
        Status: [''],
        Hobbies: ['']
       
    });


    this.registerFormUpdate = this.formBuilder.group({
      EmpNames: [''],
      Addresss: [''],     
      Country_Ids: [''],
      State_Ids: [''],
      City_Ids: ['']
        
  });

this.getEmployee();
this.GetCountry();
this.GetHobbies();

this.Chklst_dropdownSettings = { 
  singleSelection: false, 
  text:"Select Hobbies",
  selectAllText:'Select All',
  unSelectAllText:'UnSelect All',
  enableSearchFilter: true,
  classes:"myclass custom-class"
};  

    }


    get f() { return this.registerForm.controls; }
    
   // get f1() { return this.registerFormUpdate.controls; }

  //  ////file upload work start

  //   public uploader: FileUploader = new FileUploader({
  //     url: URL,
  //     disableMultipart : false,
  //     autoUpload: true,
  //     method: 'post',
  //     itemAlias: 'attachment',
  //     allowedFileType: ['image', 'pdf']
  
  
  //     });
  

  //   public onFileSelected(event: EventEmitter<File[]>) {
  //     const file: File = event[0];
  //     console.log(file);
  
  //   }

 ////file upload work end

////Checkboxlist work start


GetHobbies(){
  this.dataservice.GetHobbies().subscribe(res=>{
    if(res){
          this.Chklst_dropdownList = res;
          console.log(this.Chklst_dropdownList,"ggg")
     let test = this.Chklst_dropdownList.map(function(obj) { 
        obj['itemName'] = obj['Hobbies_Name'];
        obj['id'] = obj['pkHobbies_Id'];
        delete obj['Hobbies_Name'];
        delete obj['pkHobbies_Id'];
        return obj; 
    }); 

    this.setHobbies = test;
    }
  
    },err=>{
    // task for failure
    })
  }

  onClickSubmit2(){
    let empData = {
      EmpName:this.registerForm.controls['EmpName'].value,
      Address:this.registerForm.controls['Address'].value,
      MobileNo:this.registerForm.controls['MobileNo'].value,
      Remark:this.registerForm.controls['Remark'].value,
      PinNo:this.registerForm.controls['PinNo'].value,
      Email:this.registerForm.controls['Email'].value,
      Password:this.registerForm.controls['Password'].value,
      Gender:this.registerForm.controls['Gender'].value,
      JoinDate:this.registerForm.controls['JoinDate'].value,
      Country_Id:this.registerForm.controls['Country_Id'].value,
      Hobbies:this.registerForm.controls['Hobbies'].value.map(item=>{return item.itemName}).join(","),
      Status:this.registerForm.controls['Status'].value,
      State_Id:this.registerForm.controls['State_Id'].value,
      City_Id:this.registerForm.controls['City_Id'].value
      }
  
    console.log(empData,"reg",this.registerForm)
    //this.Chklst_selectedItems.map(item=>{return item.itemName}).join(",")
    this.dataservice.addEmployee(empData).subscribe(res=>{
      if(res){
        // this.Chklst_selectedItems=[];
        this.getEmployee();
        this.registerForm.reset();
      }
      console.log(res,"kktestres");
    // task for suceess
    console.log(JSON.stringify(res));
    },err=>{
    // task for failure
    })
  }

    onItemSelect(item:any){
   this.hobbiesArr.push(item.itemName);
   console.log(this.hobbiesArr);
    }
    OnItemDeSelect(item:any){
      console.log(item);
      console.log(this.Chklst_selectedItems);
    }
    onSelectAll(items: any){
      console.log(items);
    }
    onDeSelectAll(items: any){
      console.log(items);
    }


   ////Checkboxlist work End

    getEmployee(){
      this.dataservice.getEmployee().subscribe(res=>{
        if(res){
    this.allEmployees =res;

        }
       console.log(JSON.stringify(res),"get kk");
        },err=>{
        // task for failure
        })

      }
      SearchEmployee(employeeName){
        console.log(employeeName);
        this.dataservice.SearchEmployee(employeeName).subscribe(res=>{ 
           console.log(res,"kk",employeeName);
           if(res){
          
           this.allEmployees =res;
           if(!this.allEmployees.length){
             this.showMessage=true;
           }else{
             this.showMessage=false;
           }
           }
       
         },err=>{
           // task for failure
           })

             }

      GetCountry(){
      this.dataservice.GetCountry().subscribe(res=>{
        if(res){
          this.countryData = res;
        }
       
       console.log(JSON.stringify(res));
      
        },err=>{
        // task for failure
        })
      }



Edit_Employee(empid,index)
{
  this.isEdit=true;
  this.rowIndex = index;
  console.log(this.rowIndex,index,"igh");
  this.dataservice.Edit_Employee(empid).subscribe(res=>{ 
    console.log(res,"kk",empid);
    if(res){ 
      console.log(res,"emppkk");
    this.registerFormUpdate.controls['EmpNames'].setValue(res[0].EmpName),
    this.registerFormUpdate.controls['Addresss'].setValue(res[0].Address),
    this.registerFormUpdate.controls['Country_Ids'].setValue(res[0].Country_Id),
    this.registerFormUpdate.controls['State_Ids'].setValue(res[0].State_Id),
    this.registerFormUpdate.controls['City_Ids'].setValue(res[0].City_Id),
  //this.registerForm.patchValue(res[0]);

      
     this.empid =res[0].EmpId;
      
       
    }
    },err=>{
    // task for failure
    })
}


onClickupdateEmployee(){
  console.log(this.empid,"EEEEE");
  let empData = {
    EmpName:this.registerFormUpdate.controls['EmpNames'].value,
    Address:this.registerFormUpdate.controls['Addresss'].value,
    Country_Id:this.registerFormUpdate.controls['Country_Ids'].value,
    State_Id:this.registerFormUpdate.controls['State_Ids'].value,
    City_Id:this.registerFormUpdate.controls['City_Ids'].value

    }

 empData['EmpId'] = this.empid;

   console.log(empData,"empData");

  this.dataservice.updateEmployees(empData).subscribe(res=>{
  // task for suceess
  if(res){
    this.isEdit =false;
    this.getEmployee();
   // this.registerForm.reset();
   this.registerFormUpdate.reset();
  }
  console.log(JSON.stringify(res));
 
  },err=>{
  // task for failure
  })
   
     }
     
     GetState2(data){
       console.log(data.target.value);
       let country_id = data.target.value.split(" ")[1];
 
 this.dataservice.GetState(country_id).subscribe(res=>{
   if(res){
     this.State = res;
     console.log(JSON.stringify(res));
   }
    
   },err=>{
   // task for failure
   })

     }

  
        GetCity2(data){
          console.log(data.target.value,"sdgs");
          let state_id = data.target.value.split(" ")[1];
         this.dataservice.GetCity(state_id).subscribe(res=>{
          if(res){
            this.City = res;
          }
         
         console.log(JSON.stringify(res));
        
          },err=>{
          // task for failure
          })
       
               }

         
      Delete_Employee(data){
              this.dataservice.deleteEmployee(data).subscribe(res=>{
                if(res){
                  this.getEmployee();
                }
      // task for suceess
      console.log(JSON.stringify(res));
      },err=>{
      // task for failure
      })
          }




}
