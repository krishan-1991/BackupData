import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  
import { EmployeeDataService } from '../Services/EmployeeDataService';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
    providers:[EmployeeDataService]
})
export class LoginComponent implements OnInit {

  LoginForm: FormGroup;
  constructor(private dataservice: EmployeeDataService,private route:Router,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.LoginForm = this.formBuilder.group({
      Email: ['',[Validators.required, Validators.email]],
      Password: ['',[Validators.required, Validators.minLength(8)]]    
  });

  }

  get f() { return this.LoginForm.controls; }
  
  onClickloginSubmit(){

let LoginData = {
  Email:this.LoginForm.controls['Email'].value,
  Password:this.LoginForm.controls['Password'].value
}
    
    console.log(LoginData,"LoginDatakk")
    this.dataservice.CheckAuthByUserName_pwd(LoginData).subscribe(res=>{
      if(res)
      {
        console.log(res,this.route);
        this.route.navigate(['/employee']);
     alert("Login User Successfully!!!");

      }
      else {
        alert("Invalid username and Password");
      }
    // task for suceess
    },err=>{
    // task for failure
    })
    
  }

}
